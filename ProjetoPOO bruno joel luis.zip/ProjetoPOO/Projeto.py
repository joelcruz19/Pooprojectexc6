import os
from flask import Flask, render_template, request, send_from_directory


app = Flask(__name__, static_folder="uploads")
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
app.config["UPLOAD_FOLDER"] = 'C:/Users/Joel Cruz/Desktop/programas/ProjetoPOO/uploads'


print(APP_ROOT)

@app.route("/")
def inicioaposUPLOAD():
    return render_template("PaginaInicial.html")

@app.route("/PaginaInicial.html")
def inicio():
    return render_template("PaginaInicial.html")

@app.route("/Upload.html")
def uploadabout():
    return render_template("Upload.html")


@app.route("/upload", methods=['POST'])
def upload():
    target = os.path.join(APP_ROOT, 'uploads/')
    print(target)

    if not os.path.isdir(target):
        os.mkdir(target)

    for file in request.files.getlist("file"):
        print(file)
        filename = file.filename
        destination = "/".join([target,filename])
        print(destination)
        file.save(destination)


    return render_template("Fim.html", image_name=filename)

@app.route("/Download.html")
def downloadabout():
    return render_template("Download.html")

@app.route("/Download.html/<image_name>")
def downloader(image_name):
    return send_from_directory(
        app.config['UPLOAD_FOLDER'], filename=image_name, as_attachment=True
    )






if __name__ == '__main__':
    app.run(port=7777, debug=True)
