import urllib.request

def dlimagens(url,filepath,filename):
    full_path = filepath + filename + '.jpg'
    urllib.request.urlretrieve(url,full_path)

url = input("insira url: ")
filename = input("salvar como: ")

dlimagens(url,"imagens/",filename)
